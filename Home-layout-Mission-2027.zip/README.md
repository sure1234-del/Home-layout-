# Mission 2027 — iPad-inspired UPSC Study OS

This is a tablet-first Progressive Web App for UPSC CSE Prelims 2027. The app is at the repository root (`index.html`) so GitHub Pages can serve it directly.

## Deploy
1. Upload the contents of this folder to the root of `sure1234-del/Home-layout-` on the `main` branch.
2. In GitHub, open **Settings → Pages**.
3. Select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
4. Open `https://sure1234-del.github.io/Home-layout-/` in Chrome on the Redmi Pad SE.
5. Use Chrome menu → **Install app** / **Add to Home screen**.

## Modules
- Overview dashboard with live clock, live exam countdown, study goal, task progress and Zite snapshot.
- Daily planner with date, subject, priority, planned minutes, filters and completion tracking.
- Focus Studio with 25/5, 50/10, 90/20 and custom timer, break timer, stopwatch, lap splits and distraction-free view.
- PYQ attempt log, accuracy, revision flags, CSV export and Zite CSV/JSON import with local question browsing.
- Mock Lab with score/accuracy calculations, test history and 50-mock personal target.
- Current Affairs queue and monthly completion tracker.
- Geo Atlas revision log and Zite table shortcuts.
- Subject readiness, 14-day study chart, manual study-hour logs and weekly consistency.
- Configurable shortcuts, light/dark theme, JSON backup and restore.

## Zite connection
The app includes verified Zite table links and a count-only snapshot from 18 Nov 2026: 2,747 PYQs, 40 mock definitions, 110 Mock 03 questions, 1,300 monthly CA MCQs, 674 Geo Atlas points, 197 CA magazine topics, 72 IR entries and 23 mock attempts. This is not a live authenticated sync. The public static app does not contain Zite credentials and does not export private notes, highlights or answer history.

## Local data and privacy
Planner, timers, PYQ attempts, mock results, CA queue and study logs are stored in browser local storage on the device. Export a JSON backup before clearing browser data or switching devices. This PWA does not replace the Android launcher, Digital Wellbeing or app-blocking controls; use Android Focus Mode / Digital Wellbeing for OS-level limits.

## Compatibility
No build step or package install is required. The app uses vanilla HTML, CSS and JavaScript. The service worker caches the shell after the first online visit. The countdown defaults to 23 May 2027 and can be edited in Settings.
