plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="com.mission.launcher";compileSdk=35
defaultConfig{applicationId="com.mission.launcher";minSdk=30;targetSdk=35;versionCode=1;versionName="1.0"}
signingConfigs{getByName("debug"){storeFile=file("debug.keystore");storePassword="android";keyAlias="androiddebugkey";keyPassword="android"}}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}}
