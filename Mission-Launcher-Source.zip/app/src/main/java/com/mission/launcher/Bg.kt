package com.mission.launcher
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.PI
import kotlin.math.sin

object SkyArt {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val r = java.util.Random(7)
    private val st = List(90) { floatArrayOf(r.nextFloat(), r.nextFloat() * 0.7f, 1f + r.nextFloat() * 2f) }
    fun season(m: Int) = when (m) { 6, 7, 8, 9 -> 1; 12, 1, 2 -> 2; 3, 4, 5 -> 3; else -> 0 }
    @Synchronized fun paint(cv: Canvas, w: Float, h: Float, hr: Float, mode: Int, month: Int, photo: Bitmap?) {
        p.style = Paint.Style.FILL; p.shader = null
        if (mode == 5 && photo != null) {
            val sc = maxOf(w / photo.width, h / photo.height); val dw = photo.width * sc; val dh = photo.height * sc
            cv.drawBitmap(photo, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), p)
            p.color = Color.BLACK; p.alpha = 70; cv.drawRect(0f, 0f, w, h, p); p.alpha = 255; return
        }
        val hh = when (mode) { 1 -> 12f; 2 -> 23f; 3 -> 6.5f; 4 -> 17.3f; else -> hr }
        val night = hh < 5.75f || hh >= 18f
        val (a, b) = when {
            night -> 0xFF0A1128.toInt() to 0xFF24366B.toInt()
            hh < 8f -> 0xFF3B4A86.toInt() to 0xFFFFA77A.toInt()
            hh < 16.5f -> 0xFF3F86F2.toInt() to 0xFFBFE3FF.toInt()
            else -> 0xFF40306F.toInt() to 0xFFFF8A5C.toInt()
        }
        p.shader = LinearGradient(0f, 0f, 0f, h, a, b, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, w, h, p); p.shader = null
        val t = (if (night) ((hh - 18 + 24) % 24) / 11.75f else (hh - 6.25f) / 11.2f).coerceIn(0f, 1f)
        val x = w * (0.1f + 0.8f * t); val y = h * (0.7f - 0.5f * sin(PI.toFloat() * t))
        if (night) {
            p.color = Color.WHITE; p.alpha = 200
            st.forEach { cv.drawCircle(it[0] * w, it[1] * h, it[2], p) }
            p.shader = RadialGradient(x, y, h * 0.2f, 0x66DDE6FF, 0x00DDE6FF, Shader.TileMode.CLAMP); cv.drawCircle(x, y, h * 0.2f, p); p.shader = null
            p.color = 0xFFF4F1DE.toInt(); cv.drawCircle(x, y, h * 0.06f, p)
            p.color = a; cv.drawCircle(x + h * 0.025f, y - h * 0.01f, h * 0.055f, p)
        } else {
            p.shader = RadialGradient(x, y, h * 0.24f, 0xCCFFE9A8.toInt(), 0x00FFE9A8, Shader.TileMode.CLAMP); cv.drawCircle(x, y, h * 0.24f, p); p.shader = null
            p.color = 0xFFFFF3C4.toInt(); cv.drawCircle(x, y, h * 0.065f, p)
        }
        when (season(month)) {
            1 -> {
                p.color = 0xFF3A4660.toInt(); p.alpha = 100; cv.drawRect(0f, 0f, w, h, p)
                p.color = 0xFFE3E9F3.toInt(); p.alpha = 80
                for (i in 0 until 7) cv.drawOval(RectF(w * (0.02f + i * 0.15f), h * (0.05f + (i % 3) * 0.06f), w * (0.26f + i * 0.15f), h * (0.15f + (i % 3) * 0.06f)), p)
                p.color = Color.WHITE; p.alpha = 90; p.style = Paint.Style.STROKE; p.strokeWidth = 2f
                for (i in 0 until 70) { val s = st[i % st.size]; val rx = s[0] * w; val ry = s[1] * 1.4f * h; cv.drawLine(rx, ry, rx - 8f, ry + h * 0.025f, p) }
                p.style = Paint.Style.FILL; p.alpha = 255
            }
            2 -> { p.shader = LinearGradient(0f, h * 0.5f, 0f, h, 0x00E8EEF5, 0x99E8EEF5.toInt(), Shader.TileMode.CLAMP); cv.drawRect(0f, h * 0.5f, w, h, p); p.shader = null }
            3 -> if (!night) { p.color = 0xFFFF9A3C.toInt(); p.alpha = 34; cv.drawRect(0f, 0f, w, h, p); p.alpha = 255 }
        }
    }
}

object Bg {
    private fun pi(c: Context, code: Int, act: String?): PendingIntent { val i = Intent(c, TickReceiver::class.java); if (act != null) i.action = act; return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
    private fun alarm(c: Context, at: Long, p: PendingIntent) { val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager; try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p) } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p) } }
    fun sched(c: Context) { val t = LocalDateTime.now().plusHours(1).withMinute(0).withSecond(5).withNano(0); alarm(c, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi(c, 1, null)) }
    fun focusAlarm(c: Context, at: Long) = alarm(c, at + 1000, pi(c, 2, "focus"))
    fun clearCache(c: Context) { for (d in listOfNotNull(c.cacheDir, c.externalCacheDir)) d.listFiles()?.forEach { it.deleteRecursively() } }
    fun waterToday(c: Context): Int { val t = LocalDate.now().toString(); return (c.getSharedPreferences("m", 0).getString("water", "") ?: "").split("\n").filter { it.startsWith("$t|") }.sumOf { it.substringAfter("|").toIntOrNull() ?: 0 } }
    fun addWater(c: Context, ml: Int) { val p = c.getSharedPreferences("m", 0); p.edit().putString("water", ((p.getString("water", "") ?: "") + "\n${LocalDate.now()}|$ml").trim()).apply() }
    fun dnd(c: Context, on: Boolean) { try { val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_ALL) } catch (e: Exception) { } }
    fun finishFocusIfDue(c: Context) {
        val p = c.getSharedPreferences("m", 0); val e = p.getLong("fend", 0)
        if (e > 0 && System.currentTimeMillis() >= e) { val k = "fm_" + LocalDate.now(); p.edit().putInt(k, p.getInt(k, 0) + p.getInt("flen", 0)).putLong("fend", 0).apply(); dnd(c, false) }
    }
    fun setWallpaper(c: Context) {
        val dm = Resources.getSystem().displayMetrics; val w = minOf(dm.widthPixels, dm.heightPixels); val h = maxOf(dm.widthPixels, dm.heightPixels)
        val p = c.getSharedPreferences("m", 0); val mode = p.getInt("wall", 0); val n = LocalTime.now()
        val photo = if (mode == 5) BitmapFactory.decodeFile(File(c.filesDir, "wall.jpg").path) else null
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        SkyArt.paint(Canvas(bm), w.toFloat(), h.toFloat(), n.hour + n.minute / 60f, mode, if (p.getBoolean("season", true)) LocalDate.now().monthValue else 0, photo)
        WallpaperManager.getInstance(c).setBitmap(bm, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        bm.recycle()
    }
    fun overlay(c0: Context) {
        val c = c0.applicationContext; val p = c.getSharedPreferences("m", 0)
        val goal = p.getInt("wgoal", 3000); val have = waterToday(c); val hr = LocalTime.now().hour
        if (!p.getBoolean("walert", true) || have >= goal || hr < 7 || hr >= 22) return
        if (!(c.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return
        if (System.currentTimeMillis() - p.getLong("wlast", 0) < 110 * 60000L) return
        p.edit().putLong("wlast", System.currentTimeMillis()).apply()
        Handler(Looper.getMainLooper()).post {
            if (!Settings.canDrawOverlays(c)) { Toast.makeText(c, "💧 Drink water ($have/$goal ml)", Toast.LENGTH_LONG).show(); return@post }
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager; val d = c.resources.displayMetrics.density
            val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt()); background = GradientDrawable().apply { setColor(0xEE1B2B4F.toInt()); cornerRadius = 22 * d; setStroke(d.toInt().coerceAtLeast(1), 0x66FFFFFF) } }
            box.addView(TextView(c).apply { text = "💧 Time to drink water"; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD })
            box.addView(TextView(c).apply { text = "$have / $goal ml today - stay hydrated 🌿"; setTextColor(0xCCFFFFFF.toInt()); textSize = 11f })
            val row = LinearLayout(c).apply { setPadding(0, (8 * d).toInt(), 0, 0) }
            fun btn(t: String, f: () -> Unit) = TextView(c).apply { text = t; setTextColor(Color.WHITE); textSize = 12f; setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt()); background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = 14 * d }
                setOnClickListener { f(); try { wm.removeView(box) } catch (e: Exception) { } } }
            row.addView(btn("+250 ml 🥛") { addWater(c, 250) }); row.addView(btn("+500 ml 🍶") { addWater(c, 500) }); row.addView(btn("Later") { })
            box.addView(row)
            val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = (16 * d).toInt(); y = (40 * d).toInt() }
            try { wm.addView(box, lp); Handler(Looper.getMainLooper()).postDelayed({ try { wm.removeView(box) } catch (e: Exception) { } }, 25000) } catch (e: Exception) { }
        }
    }
}

class TickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pr = goAsync(); val act = i.action
        Thread {
            try {
                Bg.finishFocusIfDue(c)
                if (act != "focus") { Bg.clearCache(c); val p = c.getSharedPreferences("m", 0); if (p.getBoolean("wallsys", true) && p.getInt("wall", 0) != 5) Bg.setWallpaper(c); Bg.overlay(c) }
            } catch (e: Exception) { } finally { if (act != "focus") Bg.sched(c); pr.finish() }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { Bg.sched(c) } }

object UI { var s = 1f }
