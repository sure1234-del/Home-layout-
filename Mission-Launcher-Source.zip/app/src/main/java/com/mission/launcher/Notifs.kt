package com.mission.launcher
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
class Notifs : NotificationListenerService() {
    private val block = setOf("com.instagram.android","com.facebook.katana","com.google.android.youtube","com.snapchat.android","com.twitter.android","com.reddit.frontpage","com.amazon.mShop.android.shopping","com.flipkart.android","com.zhiliaoapp.musically","in.mohalla.sharechat")
    private val keep = setOf("com.google.android.gm","com.google.android.apps.messaging","com.whatsapp","org.telegram.messenger","com.google.android.calendar","com.google.android.apps.classroom")
    override fun onNotificationPosted(s: StatusBarNotification) {
        if (s.packageName in block && s.isClearable) {
            val q = getSharedPreferences("m", 0)
            val e0 = s.notification.extras
            val line = "${s.packageName}: ${e0.getCharSequence(Notification.EXTRA_TITLE) ?: ""}".replace("\n", " ")
            val old = (q.getString("muted", "") ?: "").split("\n").filter { it.isNotBlank() }
            q.edit().putString("muted", (listOf(line) + old).take(50).joinToString("\n")).apply()
            cancelNotification(s.key); return
        }
        if (s.packageName !in keep) return
        val e = s.notification.extras
        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val x = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (t.isEmpty() && x.isEmpty()) return
        val p = getSharedPreferences("m", 0)
        val l = (p.getString("imp", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        l.add(0, "$t: $x".replace("\n", " "))
        p.edit().putString("imp", l.take(5).joinToString("\n")).apply()
    }
}
