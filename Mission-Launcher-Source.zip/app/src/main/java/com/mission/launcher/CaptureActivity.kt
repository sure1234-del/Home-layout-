package com.mission.launcher
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import java.time.LocalDate

class CaptureActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("m", 0)
        val e = EditText(this).apply { hint = "Type or paste"; setText(intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""); minLines = 3; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        fun txt() = e.text.toString().trim().replace("\n", " ").replace("|", " ")
        fun save(k: String, v: String) { p.edit().putString(k, ((p.getString(k, "") ?: "") + "\n" + v).trim()).apply() }
        fun done(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); finish() }
        val d = AlertDialog.Builder(this).setTitle("Quick capture").setView(e)
            .setPositiveButton("Note") { _, _ -> if (txt().isNotEmpty()) { save("notes", "${LocalDate.now()}|${txt()}"); done("Saved to notes") } else finish() }
            .setNeutralButton("Task") { _, _ -> if (txt().isNotEmpty()) { save("plan", "${LocalDate.now()}|0|${txt()}"); done("Task added for today") } else finish() }
            .setNegativeButton("More") { _, _ ->
                AlertDialog.Builder(this).setItems(arrayOf("Add to revision list", "Ask AI to summarize")) { _, i ->
                    if (i == 0 && txt().isNotEmpty()) { save("rev", "${txt().take(80)}|${LocalDate.now()}|0"); done("Added to revision list") }
                    else if (i == 1 && txt().isNotEmpty()) { startActivity(Intent(this, MainActivity::class.java).putExtra("ai", "Summarize this for UPSC Prelims notes and save it as a note: " + txt()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)); finish() }
                    else finish() }.setOnCancelListener { finish() }.show() }
            .setOnCancelListener { finish() }.show()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }
}
