# Mission 2027 Launcher (Redmi Pad SE)
1. Upload ALL files (keep the `.github` folder) to a new GitHub repo, branch `main`.
2. Open the Actions tab -> "Build APK" -> wait ~4 min -> download artifact `Mission-Launcher-APK` -> unzip -> install `app-debug.apk` (allow "install unknown apps").
3. Press Home -> choose "Mission 2027" -> Always.
4. Tap the "…" dock button once to create your 6-digit PIN (apps then stay unlocked for 1 hour). Tap "Tap to enable the notification filter" and allow access.
Limits: the PIN/timer gates the launcher's app list only; apps opened from Recents, notifications or other launchers bypass it. For hard blocking also use HyperOS Security -> Digital Wellbeing / App lock.

## Gemini AI assistant
Get a key at aistudio.google.com, tap "Set key" in the AI card. The AI can only use the listed tools (planner, notes, scores, focus, open app, calendar, browser, read-only files). It cannot delete data or bypass the PIN. Allow "All files access" only if you want file reading. Anything you ask it to read is sent to Google.

## Circle to Search
Long-press an empty part of Home or tap "Circle to Search" to open the Gemini assistant overlay. The system long-press on the navigation handle is only handled by the stock launcher on many phones; the nav handle stays visible by default so you can test it. "Full screen" chip hides it too.

## Background features
Hourly alarm (survives swiping the app from Recents): refreshes wallpaper, cleans this app's cache, shows the water reminder. Allow Autostart, Battery: No restrictions and "Show over other apps" for Mission 2027 in HyperOS settings.

## Live Zite sync (JSON shape)
Settings -> Zite -> Live stats URL expects JSON:
{"updatedAt":"2026-11-20","counts":[{"label":"PYQ questions","total":2747}],"mocks":[{"title":"Mock T03 - Economy","date":"2026-12-08"}]}
Offline or without a URL the launcher shows the last live data, else the built-in snapshot (counts and mock schedule of 20 Nov 2026).
Auto-heal: each start validates saved settings, repairs bad values, re-arms hourly alarms; after 3 crashes in 3 minutes it enters safe mode (heavy widgets paused).
